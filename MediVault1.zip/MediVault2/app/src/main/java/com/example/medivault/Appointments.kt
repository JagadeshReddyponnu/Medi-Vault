package com.example.medivault

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class Appointments : AppCompatActivity() {
    private lateinit var container: LinearLayout
    private lateinit var searchEditText: EditText
    private lateinit var searchButton: Button
    private lateinit var dbHelper: DatabaseHelper

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_appointments)

        container = findViewById(R.id.Appointmentscontainer)
        searchEditText = findViewById(R.id.AppointmentssearchEditText)
        searchButton = findViewById(R.id.AppointmentssearchButton)
        dbHelper = DatabaseHelper(this)

        searchButton.setOnClickListener {
            val patientId = searchEditText.text.toString().trim()
            if (patientId.isNotEmpty()) {
                displayPatientRecords(patientId)
            } else {
                displayPatientRecords()
            }
        }

        displayPatientRecords()
    }

    private fun displayPatientRecords(patientIdFilter: String? = null) {
        container.removeAllViews()
        val allPatients = dbHelper.getAllPatients()
        val patients = if (patientIdFilter != null) {
            allPatients.filter { it[DatabaseHelper.COLUMN_ID].toString() == patientIdFilter }
        } else {
            allPatients
        }

        val sharedPreferences = getSharedPreferences("com.example.medivault.appointments", Context.MODE_PRIVATE)

        for (patient in patients) {
            val recordLayout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(10, 10, 10, 10)
            }

            fun makeBoldLabel(label: String, value: String): SpannableStringBuilder {
                val spannable = SpannableStringBuilder("$label: $value")
                spannable.setSpan(StyleSpan(Typeface.BOLD), 0, label.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                return spannable
            }

            val idView = TextView(this).apply {
                text = makeBoldLabel("Candidate Id", patient[DatabaseHelper.COLUMN_ID].toString())
                textSize = 18f
            }

            val nameView = TextView(this).apply {
                text = makeBoldLabel("Name", patient[DatabaseHelper.COLUMN_NAME].toString())
                textSize = 18f
            }

            val diseaseView = TextView(this).apply {
                text = makeBoldLabel("Disease", patient[DatabaseHelper.COLUMN_DISEASE_DETAILS].toString())
                textSize = 18f
            }

            val patientId = patient[DatabaseHelper.COLUMN_ID].toString()
            val savedDateTime = sharedPreferences.getString(patientId, "No appointment selected")

            val appointmentTextView = TextView(this).apply {
                text = savedDateTime
                textSize = 16f
                setTextColor(Color.BLACK)
                setPadding(10, 5, 10, 5)
            }

            val dateTimeButton = Button(this).apply {
                text = " Select Date & Time "
                setTextColor(Color.WHITE)
                textSize = 12f
                setBackgroundColor(resources.getColor(android.R.color.holo_blue_light))
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    gravity = Gravity.CENTER_HORIZONTAL
                    setMargins(10, 5, 10, 5)
                }

                setOnClickListener {
                    showDateTimePicker(patientId, appointmentTextView)
                }
            }

            recordLayout.addView(idView)
            recordLayout.addView(nameView)
            recordLayout.addView(diseaseView)
            recordLayout.addView(dateTimeButton)
            recordLayout.addView(appointmentTextView)

            val separator = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 3
                )
                setBackgroundColor(Color.BLACK)
            }

            container.addView(recordLayout)
            container.addView(separator)
        }

        if (patients.isEmpty()) {
            val emptyText = TextView(this).apply {
                text = "No records found."
                textSize = 16f
                setTextColor(Color.GRAY)
                gravity = Gravity.CENTER
            }
            container.addView(emptyText)
        }
    }

    private fun showDateTimePicker(patientId: String, appointmentTextView: TextView) {
        val calendar = Calendar.getInstance()
        DatePickerDialog(this, { _, year, month, dayOfMonth ->
            val selectedDate = "$dayOfMonth/${month + 1}/$year"
            TimePickerDialog(this, { _, hourOfDay, minute ->
                val selectedTime = String.format("%02d:%02d", hourOfDay, minute)
                val formattedDateTime = "Appointment Scheduled on $selectedDate $selectedTime"
                val sharedPreferences = getSharedPreferences("com.example.medivault.appointments", Context.MODE_PRIVATE)
                with(sharedPreferences.edit()) {
                    putString(patientId, formattedDateTime)
                    apply()
                }
                appointmentTextView.text = formattedDateTime
                Toast.makeText(this, "Appointment Set: $formattedDateTime", Toast.LENGTH_SHORT).show()
            }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), false).show()
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
    }
}
